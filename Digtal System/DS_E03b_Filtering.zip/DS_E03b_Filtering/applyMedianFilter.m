function [ img_out ] = applyMedianFilter( img_in )
% put your code here
end