%**************************************************************************
%                          - Exercises E04 -
%                Excercise 5 - Image Filtering II - MATLAB
%
% Date: 
% Name: 
%**************************************************************************
close all;

% load image

% show image

% apply median filter


% show results