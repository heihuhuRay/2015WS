/*
 *  crc_calc.h
 *  crc4 calculation -- EDA tools
 *  generation poly  x^4 + x + 1
 *  
 *  Created by Lei Yang and Sven Quinger, October 2013
 *  Copyright 2013 __SSE__. All rights reserved.
 *
 */

#ifndef CRC_CALC_H
#define CRC_CALC_H

#include "systemc.h"
#include "iostream"
#include "iomanip"

SC_MODULE(crc_calc) {

	// ports
	sc_in_clk				clk;
	sc_in	< bool >			reset;
	sc_in	< bool >			crc_en;
	sc_in	< bool >			data_in;
	sc_out	< sc_uint <4> >			crc_out;

	// variables


	// functions
	void crc4();
	

};

#endif

