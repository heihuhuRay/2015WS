#include "crc_calc.h"
#include "crc_testbench.h"
#include "systemc.h"
#include "iostream"
#include "iomanip"

int sc_main(int argc, char* argv[]){

	cout << "Starting the Test" << endl;
	
	sc_core::sc_set_time_resolution(1, SC_MS);

	sc_clock				clk("clk",sc_time(10, SC_MS));
	sc_core::sc_signal<bool	>		reset;
	sc_core::sc_signal<bool>		data_in;
	// ... add missing lines 

	
	crc_calc *dut = new crc_calc("crc_calc");
	dut->clk(clk);
	dut->crc_en(crc_en);
	// ... add missing lines
	
	crc_testbench *stimgen = new crc_testbench("StimGen");
	stimgen->clk(clk);
	stimgen->reset(reset);
	stimgen->crc_en(crc_en);
	stimgen->data_in(data_in);
	stimgen->crc_out(crc_out);

	
	sc_core::sc_trace_file *tf = sc_core::sc_create_vcd_trace_file("crc-calc");
	// ... add missing lines
	
	sc_core::sc_start(1,sc_core::SC_SEC);
	sc_core::sc_close_vcd_trace_file(tf);
	
	cout << "Test completed." << endl;

	return 0;
	
}

