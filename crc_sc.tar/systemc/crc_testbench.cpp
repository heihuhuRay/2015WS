/*
 *  crc_tb_ext.cpp
 *  extended testbench for checking crc4 generator in EDA tools SystemC-lab
 *
 *  Created by Lei Yang and Sven Quinger, October 2013
 *  Copyright 2013 __SSE__. All rights reserved.
 *
 */

#include "crc_testbench.h"


void crc_testbench::verify_crc(sc_uint<11> data){
	sc_uint < 15 >	temp;
	sc_uint < 4 >	crc = 0;
	sc_uint < 5 >	crc_poly = CRC_POLY;
	
	unsigned int i;
	
	temp = (data, crc);

	 // crc generation
	 for (i=14; i>=4; i--) {
		 if (temp[i]) {
			 temp.range(i-1,i-4) = temp.range(i-1,i-4) ^ crc_poly.range(3,0);
		 }
	 }
	 
	crc = temp.range(3,0);

	cout << "The correct CRC-Checksum for message " << data << " is " << crc << "." << endl;
}


void crc_testbench::stimulus() {

	sc_uint <11>	data;
	sc_uint <4>	crc;
	unsigned int 	i;
	int 		tcount;
	

	for (tcount=0; tcount<3; tcount++) {
	
		crc = 0;

		switch (tcount) {
			case 0:	
				data = sc_uint<11>(CRC_MESSAGE);
				break;
			
			case 1: 
				data = sc_uint<11>(CRC_MESSAGE_2);
				break;

			case 2: 
				data = sc_uint<11>(CRC_MESSAGE_3);
				break;
			
			default:
				data = sc_uint<11>(0x7ff);
				break;
		}
		cout << endl;
		cout << "The message to calculate CRC-Checksum for is " << data << "." << endl;
	
		reset = true;
		wait(50, SC_MS);
		
		reset = false;
		wait(10, SC_MS);
		
		crc_en = true;
	
		for (i = 0; i < 11; i++) {
			data_in = data[(10)-i];
			wait (10, SC_MS);
		}
	
		crc_en = false;
			
		cout << "The CRC-Checksum you've calculated is " << crc_out << "." << endl;

		verify_crc(data);

		wait(50, SC_MS);

	
	
		reset = true;
	}
}




