/*
 *  crc_testbench_ext.h
 *  crc4 testbench -- EDA tools
 *
 *  Created by Lei Yang and Sven Quinger, October 2013
 *  Copyright 2013 __SSE__. All rights reserved.
 *
 */

#ifndef CRC_TESTBENCH_H
#define CRC_TESTBENCH_H

#include "systemc.h"

#define CRC_POLY			0x13
#define CRC_MESSAGE			0x3fa
#define CRC_MESSAGE_2			0x361
#define CRC_MESSAGE_3			0x43A

SC_MODULE(crc_testbench) {
	// ports
	sc_in_clk			clk;
	sc_in	< sc_uint <4> >		crc_out;
	sc_out	< bool >		reset;
	sc_out	< bool >		crc_en;
	sc_out	< bool >		data_in;

	void stimulus();
	void verify_crc(sc_uint<11> data);

	SC_CTOR(crc_testbench) {
		
		SC_THREAD(stimulus);
		sensitive << reset << clk.pos();
		
	}
};
#endif
