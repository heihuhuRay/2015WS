#include "crc_calc.h"
#include <systemc.h>
#include <iostream>

void crc_calc::crc4(){

// implement function here	

}

